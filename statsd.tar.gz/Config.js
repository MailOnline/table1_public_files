{
  port: 8125
, flushInterval: 10000
, debug: true
, deleteGauges: true
, dumpMessages: true
, graphitePort: 2003
, graphiteHost: "10.224.13.141"
, backends: [ "./backends/graphite" ]
, graphite: {
    globalSuffix: require('os').hostname().split('.')[0]
  }
}
