#!/bin/bash

. /etc/profile
export LD_LIBRARY_PATH="/opt/local/gcc47/x86_64-sun-solaris2.11/lib/amd64:/var/cfengine/lib"
	
/usr/sbin/svcadm disable MOLstatsd
/usr/sbin/svccfg delete MOLstatsd
rm -rf /opt/molsfw/statsd
