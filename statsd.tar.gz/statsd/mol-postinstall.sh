#!/usr/bin/bash

. /etc/profile

if [ "$2" = "POST-INSTALL" ]; then
	groupadd -g 2015 statsd
	useradd -u 2015 -s /usr/bin/pfbash -g statsd -m -d /opt/molsfw/statsd statsd
	usermod -K defaultpriv=basic,net_privaddr,net_rawaccess,file_dac_read,file_dac_write,file_dac_search statsd
	chown -R statsd:statsd /opt/molsfw/statsd*
	svccfg import /opt/molsfw/statsd/smf_manifests/statsd.xml
fi

