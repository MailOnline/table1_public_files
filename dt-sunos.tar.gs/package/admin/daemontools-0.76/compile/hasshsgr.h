/* Public domain. */

/* sysdep: -shortsetgroups */
