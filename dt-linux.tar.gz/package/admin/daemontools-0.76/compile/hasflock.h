/* Public domain. */

/* sysdep: +flock */
#define HASFLOCK 1
