#ifndef TIMESTAMP_H
#define TIMESTAMP_H

#define TIMESTAMP 25

extern void timestamp(char *);

#endif
