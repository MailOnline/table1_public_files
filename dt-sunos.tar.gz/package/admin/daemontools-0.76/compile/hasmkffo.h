/* Public domain. */

/* sysdep: +mkfifo */
#define HASMKFIFO 1
