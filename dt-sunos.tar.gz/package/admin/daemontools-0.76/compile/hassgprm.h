/* Public domain. */

/* sysdep: +sigprocmask */
#define HASSIGPROCMASK 1
