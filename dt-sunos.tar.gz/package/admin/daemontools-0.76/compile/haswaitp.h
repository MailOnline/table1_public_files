/* Public domain. */

/* sysdep: +waitpid */
#define HASWAITPID 1
