/* Public domain. */

#ifndef DIRENTRY_H
#define DIRENTRY_H

/* sysdep: +dirent */

#include <sys/types.h>
#include <dirent.h>
#define direntry struct dirent

#endif
