/* Public domain. */

/* sysdep: +sigaction */
#define HASSIGACTION 1
