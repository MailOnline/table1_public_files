/* Public domain. */

#ifndef UINT64_H
#define UINT64_H

/* sysdep: +ulong64 */

typedef unsigned long uint64;

#endif
