/* Public domain. */

/* sysdep: -flock */
